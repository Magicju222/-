import streamlit as st
import os
from typing import Optional

# Try to import supabase, but don't crash if missing
try:
    from supabase import create_client, Client
    SUPABASE_INSTALLED = True
except ImportError:
    SUPABASE_INSTALLED = False
    Client = None

# Initialize Supabase client
# Uses st.secrets in production, or environment variables locally
def init_supabase() -> Optional[Client]:
    if not SUPABASE_INSTALLED:
        return None
        
    url = os.environ.get("SUPABASE_URL")
    key = os.environ.get("SUPABASE_KEY")
    
    # Try loading from streamlit secrets if env vars are missing
    if not url or not key:
        try:
            if not url:
                url = st.secrets["SUPABASE_URL"]
            if not key:
                key = st.secrets["SUPABASE_KEY"]
        except Exception:
            # Secrets not found or keys missing
            pass
    
    if not url or not key:
        return None
        
    try:
        return create_client(url, key)
    except Exception as e:
        print(f"Supabase connection error: {e}")
        return None

def is_auth_enabled() -> bool:
    """Check if authentication should be enabled (i.e., credentials exist)."""
    return init_supabase() is not None

def show_login_page():
    # CSS for centering and styling
    st.markdown("""
    <style>
        div.stButton > button {
            width: 100%;
            height: 48px;
            font-weight: 600;
            border-radius: 12px; /* var(--radius-sm) fallback */
            
            /* Glassmorphism */
            background-color: rgba(255, 255, 255, 0.65); /* var(--color-bg-card) fallback */
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.5); /* var(--color-border-light) fallback */
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02); /* var(--shadow-sm) fallback */
            
            color: #1d1d1f; /* var(--color-text-primary) fallback */
            transition: all 0.3s ease;
        }

        div.stButton > button:hover {
            background-color: rgba(255, 255, 255, 0.85); /* var(--color-bg-card-hover) fallback */
            box-shadow: 0 12px 32px rgba(0, 122, 255, 0.15); /* var(--shadow-blue-glow) fallback */
            border-color: #007AFF; /* var(--color-accent-blue) fallback */
            color: #007AFF;
            transform: translateY(-2px);
        }
        
        /* Ensure primary button override */
        div.stButton > button[kind="primary"] {
            background-color: rgba(255, 255, 255, 0.65);
            color: #1d1d1f;
            border: 1px solid rgba(255, 255, 255, 0.5);
        }
        div.stButton > button[kind="primary"]:hover {
             background-color: rgba(255, 255, 255, 0.85);
             color: #007AFF;
             border-color: #007AFF;
        }
    </style>
    """, unsafe_allow_html=True)
    
    # Vertical spacer to push content to middle
    st.markdown("<div style='height: 10vh'></div>", unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([1, 1.5, 1])
    
    with col2:
        st.markdown("<h2 style='text-align: center;'>🔐 AI Excel 清洗助手</h2>", unsafe_allow_html=True)
        
        # Container for the card effect
        with st.container(border=True):
            tab1, tab2 = st.tabs(["用户登录", "新用户注册"])
            
            supabase = init_supabase()
            
            if not supabase:
                st.error("系统配置错误：缺少 Supabase URL 或 Key。")
                return

            with tab1:
                email = st.text_input("电子邮箱", key="login_email", placeholder="name@example.com")
                password = st.text_input("登录密码", type="password", key="login_pass", placeholder="请输入密码")
                
                st.markdown("<br>", unsafe_allow_html=True)
                
                if st.button("立即登录", type="primary"):
                    try:
                        response = supabase.auth.sign_in_with_password({"email": email, "password": password})
                        st.session_state.user = response.user
                        st.success("登录成功！正在跳转...")
                        st.rerun()
                    except Exception as e:
                        st.error(f"登录失败: 账号或密码错误")

            with tab2:
                new_email = st.text_input("电子邮箱", key="reg_email", placeholder="name@example.com")
                new_password = st.text_input("设置密码", type="password", key="reg_pass", placeholder="请设置您的登录密码")
                
                st.markdown("<br>", unsafe_allow_html=True)
                
                if st.button("创建账号"):
                    try:
                        response = supabase.auth.sign_up({"email": new_email, "password": new_password})
                        st.success("注册成功！请检查您的邮箱进行验证。")
                    except Exception as e:
                        st.error(f"注册失败: {str(e)}")

def check_auth():
    """
    Returns True if:
    1. Auth is NOT enabled (Local Mode)
    2. Auth IS enabled AND user is logged in
    Returns False if:
    1. Auth IS enabled AND user is NOT logged in
    """
    if not is_auth_enabled():
        return True
        
    if "user" not in st.session_state:
        st.session_state.user = None
    
    return st.session_state.user is not None

def logout():
    supabase = init_supabase()
    if supabase:
        supabase.auth.sign_out()
    st.session_state.user = None
    st.rerun()